from django.shortcuts import render
from django.http import JsonResponse
import serial
import time
from .models import SensorData
from .services import send_sms
from datetime import timedelta
from django.utils import timezone
import requests
from django.conf import settings


# Configure your Arduino serial port
SERIAL_PORT = 'COM4'  # Change this to your port
BAUD_RATE = 9600
flag=1
def index(request):
    return render(request, 'dht_app/index2.html')

def chart(req):
    return render(req,'dht_app/chart.html')

def compare(req):
    return render(req,'dht_app/compar.html')

def fetch_data(request):
    while(1):
        try:
            
            with serial.Serial(SERIAL_PORT, BAUD_RATE) as ser:
                time.sleep(2)  
                

                line = ser.readline().decode('utf-8').strip()
                data = line.split("\t")  # Split by tab character
                temperature = float(data[1].split(": ")[1].replace(" *C", "")) 
                humidity = float(data[0].split(": ")[1].replace(" %", "")) 
                datas=SensorData.objects.create(temperature=temperature,humidity=humidity)
                datas.save() 
                if(temperature>35.0):
                    phone_number = '+919342453053'  
                    message_body = 'It is too hot'
                    send_sms(phone_number,message_body)
                    return JsonResponse({'temperature': temperature, 'humidity': humidity})
                elif(temperature<25.0):
                    phone_number = '+919342453053'  
                    message_body = 'It is too cold'
                    send_sms(phone_number,message_body)
                    return JsonResponse({'temperature': temperature, 'humidity': humidity})
                else:
                    return JsonResponse({'temperature': temperature, 'humidity': humidity})
        except Exception as e:
            return JsonResponse({'error': str(e)})



def latest_data(request):
    # Fetch the latest data
    data = SensorData.objects.all().order_by('-timestamp')[:100]  # Get the last 100 entries

    # Prepare the response data
    response_data = {
        'timestamps': [entry.timestamp.strftime('%Y-%m-%d %H:%M') for entry in data],
        'temperatures': [entry.temperature for entry in data],
        'humidities': [entry.humidity for entry in data],
    }

    return JsonResponse(response_data)



def compare_data(request):
    # Fetch the latest data points (e.g., last 10 entries)
    latest_data = SensorData.objects.all().order_by('-timestamp')[:10]

    # Fetch past data points (e.g., from 1 hour ago)
    past_start_time = timezone.now() - timedelta(hours=1)
    past_data = SensorData.objects.filter(timestamp__gte=past_start_time).order_by('timestamp')

    # Prepare response data
    response_data = {
        'latest_timestamps': [entry.timestamp.strftime('%Y-%m-%d %H:%M') for entry in latest_data],
        'latest_temperatures': [entry.temperature for entry in latest_data],
        'latest_humidities': [entry.humidity for entry in latest_data],
        'past_timestamps': [entry.timestamp.strftime('%Y-%m-%d %H:%M') for entry in past_data],
        'past_temperatures': [entry.temperature for entry in past_data],
        'past_humidities': [entry.humidity for entry in past_data],
    }

    return JsonResponse(response_data)


# Define your weather API URL and API key
API_KEY = 'YOUR_API_KEY'  # Replace this with your actual OpenWeatherMap API key
BASE_URL = "http://api.openweathermap.org/data/2.5/weather?"

def weather_view(request):
    # Get city from user (you can also set a default city)
    city = request.GET.get('city', 'London')  # Default is London if city is not provided

    # Build the complete API request URL
    complete_url = f"{BASE_URL}q={city}&appid={API_KEY}&units=metric"
    
    # Make the API request to OpenWeatherMap
    response = requests.get(complete_url)
    weather_data = response.json()
    
    # Check if the response is valid
    if weather_data['cod'] == 200:
        # Extract relevant data
        context = {
            'city': weather_data['name'],
            'temperature': weather_data['main']['temp'],
            'description': weather_data['weather'][0]['description'],
            'icon': weather_data['weather'][0]['icon'],
            'humidity': weather_data['main']['humidity'],
            'wind_speed': weather_data['wind']['speed']
        }
    else:
        context = {
            'error': 'City not found!'
        }
    
    # Render the data to a template
    return render(request, 'weather.html', context)
