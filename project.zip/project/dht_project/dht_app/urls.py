from django.urls import path
from .views import fetch_data,latest_data,compare_data

urlpatterns = [
    path('fetch-data/', fetch_data, name='fetch_data'),
    path('latest-data/',latest_data,name='latest_data'),
    path('compare-data/',compare_data,name='compare-data'),
]
